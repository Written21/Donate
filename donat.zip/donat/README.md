# Aiogram 3.x Telegram Stars Payments bot example

Basic donation bot to showcase Telegram Stars Payments.
Based on Aiogram 3 with some useful speedups & async (non-blocking) libraries.
As well as basic architecture setup.

## Credits
[@MasterGroosha](https://github.com/MasterGroosha) for his Aiogram 3 getting started guides, we learned from it many cool things
